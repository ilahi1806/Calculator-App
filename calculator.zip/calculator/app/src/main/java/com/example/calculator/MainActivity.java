package com.example.calculator;

import android.os.Bundle;
import android.text.SpannableStringBuilder;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;

import org.mariuszgromada.math.mxparser.Expression;

public class MainActivity extends AppCompatActivity {
    private EditText display;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        display= findViewById(R.id.display);
        display.setShowSoftInputOnFocus(false);

        display.setOnClickListener(view -> {
            if(getString(R.string.display).equals(display.getText().toString())){
                display.setText("");
            }
        });
    }
    private void updateText(String str){
        String oldstr = display.getText().toString();
        int cursor = display.getSelectionStart();
        String leftString = oldstr.substring(0,cursor);
        String rightstr = oldstr.substring(cursor);
        if(getString(R.string.display).equals(display.getText().toString())){
            display.setText(str);
            display.setSelection(cursor + 1);
        }
        else{
            display.setText(String.format("%s%s%s", leftString, str, rightstr));
            display.setSelection(cursor + 1);
        }
    }


    public void zero (android.view.View view){
        updateText("0");
    }
    public void one(android.view.View view ){
        updateText("1");
    }
    public void two(android.view.View view ){
        updateText("2");
    }
    public void three(android.view.View view ){
        updateText("3");
    }
    public void four(android.view.View view ){
        updateText("4");
    }
    public void five(android.view.View view ){
        updateText("5");
    }
    public void six(android.view.View view ){
        updateText("6");
    }
    public void seven(android.view.View view ){
        updateText("7");
    }
    public void eight(android.view.View view ){
        updateText("8");
    }
    public void nine(android.view.View view ){
        updateText("9");
    }
    public void multiply(android.view.View view ){
        updateText("X");
    }
    public void divide(android.view.View view ){
        updateText("/");
    }
    public void plus(android.view.View view ){
        updateText("+");
    }
    public void minus(android.view.View view ){
        updateText("-");
    }
    public void square (android.view.View view ){
        updateText("^");
    }
    public void equal(android.view.View view ){
        String expression =display.getText().toString();
         expression = expression.replaceAll("X","*");

         Expression exp = new Expression(expression);
         String result = String.valueOf(exp.calculate());

         display.setText(result);
         display.setSelection(result.length());

    }
    public void bracket_open(android.view.View view ){updateText("(");}
    public void bracket_close(android.view.View view ){
        updateText(")");
    }
    public void point(android.view.View view ){
        updateText(".");
    }
    public void clear(android.view.View view ){
        display.setText("");
    }
    public void delete(android.view.View view ){
        int cursor = display.getSelectionStart();
        int textlen = display.getText().length();
        if(cursor!=0 && textlen !=0){
            SpannableStringBuilder selection = (SpannableStringBuilder) display.getText();
            selection.replace(cursor -1 , cursor,"");
            display.setText(selection);
            display.setSelection(cursor -1);

        }
    }

}